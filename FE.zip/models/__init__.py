# -*- coding: utf-8 -*-

from . import dian
from . import company
from . import invoice
from . import sequence
from . import account
from . import dian_fiscal_responsability
from . import res_partner