Librerias Requeridas <br />
sudo pip install pyopenssl <br />
sudo pip install requests <br />
sudo pip install xmltodict <br />
sudo pip install PyQRCode <br />
sudo pip pip install pypng <br />